const Admin = () => {
    return (
      <h1>My profile</h1>
    )
  }
  
  export default Admin
  