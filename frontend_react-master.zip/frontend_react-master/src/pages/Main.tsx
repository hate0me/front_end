import '../styles/main.css'
const Main = () => {
    return (
      <div id='first_frame'>
      <h1>Discover, Listen, Chatting with PodNet</h1>
      </div>
    )
  }
  
  export default Main
  